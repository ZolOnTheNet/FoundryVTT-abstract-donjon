# FoundryVTT-AbstractDongeon
a French Version of Abstract Dongeon game system for FoundryVTT. It's my first system game !
in development, be award.

I happy to present my work. I have had many problèmes ; I try to resolve them... I think is not the best way to do in foundryVTT, but it's my way...
thank to "Pillule Rouge" for french video... And "Cédric Hauteville" for some explanation and for the fluent english about video system game's FoundryVtt

based on the french translation book's of Abstact Dongeon : Abstract Donjon - i don't know terms in english... sory for coneniant

### Actualy:
  - Character sheet seem to be full for 80% 
  - NPC sheet is in developpement 80%, backup selection for dice dommage
  - objects and tresorus : 100%
  - Traits : 100%
  - Dice Attack (for NPC) : 100%
  - obstacle : 100%
  - defis : 100%
  
  with many bug, but time says !
  
  - translation : 0%
  
  I think, it can play at this time... Not fully usefull...
  
## french
Vesion du System Abstract Donjon pour la table virtuelle FoundryVTT. C'est mon premier système sur cette plateforme. Mais comme j'ai vu que personne n'a fait de proposition, je vais en faire une !

Objectif : utiliser le jeu, et perso apprendre le Javascript (et me permettre de joueur avec les potes), utiliser git et github...
  
 Merci à "Pillule rouge" pour son initiation de la création de système sur Fondry. Merci à "Cédric Hauteville" pour ses vidéo en Anglais (snif!)...


### Actuellement :
  - Feuille de personnage : fonctionne à 80% hors bug
  - Feuille de PNJ en cours : selection des dés détruits avec possibilité d'annulation
          Todo :  Attaque de dé : choix d'un dés d'attaque, puis choix d'un dé pour l'attaque soit réalisée.
                  Annulation ou validation des dés détruit
                  ajouter les dés des équipements (l'idée est que l'on peut mettre une armes ou un objet apportant un ou plusieurs dés pour que les joueurs les récupères
  - objets and trésors : 100%
  - Traits : 100%
  - Dice Attack (for NPC) : 100%
  - obstacle : 10%
  - defis : 100%
  - Tableau de résolution : 0%, faire un espace permettant au joueur de selectionner leur ennemies et leurs alliés pour simuler une rencontre. En haut, il y aura les alliées, en bas, les ennemies dans cet ordre : Adversaires, demi-boss (+ tard), Boss. C'est un projet, je ne sais pas si c'est réalisable.

  - traduction : 0%
  - faute d'orhographe : 80%
 
J'ai mis ce projet parce que je veux apprendre a faire un système sous FoundryVTT et le partager. Su cette dernière partie, j'ai compris qu'il fallait mieux passer par Github... D'où ce projet


## Instalation

Holly God ! I didn't know about this ! dezip and copy to foundrydata/data/systems, may be !? Own your risk !

\<french\> : à la grace de dieu, j'ai pas encore lu cette affaire là !! Je dirais, dezipper les fichiers dans foundrydata/data/systems à vos risques et périls !
  
